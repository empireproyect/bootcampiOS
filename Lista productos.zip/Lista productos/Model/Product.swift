
import UIKit

typealias Products = [Product]
struct Product{
    var image: String? = nil
    var name: String = ""
    var price: String = ""

}
