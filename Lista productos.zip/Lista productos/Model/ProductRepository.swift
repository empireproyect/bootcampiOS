
import Foundation

class ProductRepository {
    let productsSample = [ Product(image: "producto1",
                              name: "Basketball",
                                 price: "23EUR"),
                         Product(image: "produto2",
                              name: "Boxing Gloves",
                                 price: "35EUR") ]
}
